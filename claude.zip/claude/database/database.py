from database.connection import get_connection


class Database:

    @staticmethod
    def fetch_all(query, params=()):
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute(query, params)

        rows = cursor.fetchall()

        conn.close()

        return rows

    @staticmethod
    def fetch_one(query, params=()):
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute(query, params)

        row = cursor.fetchone()

        conn.close()

        return row

    @staticmethod
    def execute(query, params=()):
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute(query, params)

        conn.commit()

        last_id = cursor.lastrowid

        conn.close()

        return last_id