import sqlite3

from config import DATABASE
conn = sqlite3.connect(DATABASE)