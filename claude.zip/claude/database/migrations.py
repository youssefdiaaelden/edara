from database.connection import get_connection


def run_migrations():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("PRAGMA foreign_keys = ON")

    # ==========================================================
    # PRODUCTS
    # ==========================================================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS products(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        name TEXT NOT NULL,

        barcode TEXT UNIQUE NOT NULL,

        cost_price REAL NOT NULL DEFAULT 0,

        sell_price REAL NOT NULL DEFAULT 0,

        profit_margin REAL DEFAULT 0,

        quantity INTEGER NOT NULL DEFAULT 0,

        created_at TEXT DEFAULT CURRENT_TIMESTAMP,

        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # ==========================================================
    # USERS
    # ==========================================================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        username TEXT UNIQUE NOT NULL,

        password TEXT NOT NULL,

        role TEXT NOT NULL,

        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # ==========================================================
    # CUSTOMERS
    # ==========================================================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS customers(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        full_name TEXT NOT NULL,

        phone TEXT UNIQUE,

        address TEXT,

        notes TEXT,

        credit REAL DEFAULT 0,

        is_active INTEGER DEFAULT 1,

        created_at TEXT DEFAULT CURRENT_TIMESTAMP,

        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # ==========================================================
    # SALES
    # ==========================================================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sales(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        customer_id INTEGER,

        payment_type TEXT DEFAULT 'CASH',

        total_price REAL NOT NULL,

        cashier_name TEXT,

        notes TEXT,

        date TEXT DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY(customer_id)
        REFERENCES customers(id)
        ON DELETE SET NULL
    )
    """)

    # ==========================================================
    # SALES ITEMS
    # ==========================================================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sales_items(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        sale_id INTEGER NOT NULL,

        product_name TEXT NOT NULL,

        quantity INTEGER NOT NULL,

        total_price REAL NOT NULL,

        date TEXT DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY(sale_id)
        REFERENCES sales(id)
        ON DELETE CASCADE
    )
    """)

    # ==========================================================
    # CUSTOMER PAYMENTS
    # ==========================================================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS customer_payments(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        customer_id INTEGER NOT NULL,

        amount REAL NOT NULL,

        payment_date TEXT DEFAULT CURRENT_TIMESTAMP,

        notes TEXT,

        FOREIGN KEY(customer_id)
        REFERENCES customers(id)
        ON DELETE CASCADE
    )
    """)

    # ==========================================================
    # CUSTOMER TRANSACTIONS
    # ==========================================================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS customer_transactions(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        customer_id INTEGER NOT NULL,

        transaction_type TEXT NOT NULL,

        amount REAL NOT NULL,

        reference_id INTEGER,

        description TEXT,

        created_at TEXT DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY(customer_id)
        REFERENCES customers(id)
        ON DELETE CASCADE
    )
    """)

    conn.commit()
    conn.close()