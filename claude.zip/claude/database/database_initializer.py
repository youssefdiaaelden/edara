import sqlite3

conn = sqlite3.connect("database/store.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS sales_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_name TEXT,
    quantity INTEGER,
    total_price REAL,
    date TEXT
)
""")

conn.commit()
conn.close()

print("✅ sales_items table created")