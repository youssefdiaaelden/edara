from datetime import datetime

from database.db_manager import Database
from services.customer_service import CustomerService


class SalesService:

    # ======================================================
    # Complete Sale
    # ======================================================

    @staticmethod
    def complete_sale(
            cart,
            cashier_name,
            payment_type="CASH",
            customer_id=None,
            notes=""
    ):

        total = 0

        for item in cart:
            total += item["price"] * item["qty"]

        # ==========================
        # Save Invoice
        # ==========================

        sale_id = Database.execute(
            """
            INSERT INTO sales(

                customer_id,

                payment_type,

                total_price,

                cashier_name,

                notes,

                date

            )

            VALUES(?,?,?,?,?,?)
            """,
            (
                customer_id,
                payment_type,
                total,
                cashier_name,
                notes,
                datetime.now()
            )
        )

        # ==========================
        # Save Items
        # ==========================

        for item in cart:

            Database.execute(
                """
                INSERT INTO sales_items(

                    sale_id,

                    product_name,

                    quantity,

                    total_price,

                    date

                )

                VALUES(?,?,?,?,?)
                """,
                (
                    sale_id,
                    item["name"],
                    item["qty"],
                    item["price"] * item["qty"],
                    datetime.now()
                )
            )

            Database.execute(
                """
                UPDATE products

                SET quantity = quantity - ?

                WHERE barcode=?
                """,
                (
                    item["qty"],
                    item["barcode"]
                )
            )

        # ==========================
        # Credit Sale
        # ==========================

        if payment_type == "CREDIT":

            CustomerService.add_credit(

                customer_id,

                total,

                sale_id,

                f"Invoice #{sale_id}"

            )

        return sale_id

    # ======================================================
    # Sales History
    # ======================================================

    @staticmethod
    def get_sales():

        return Database.fetch_all(
            """
            SELECT *

            FROM sales

            ORDER BY id DESC
            """
        )

    # ======================================================
    # One Sale
    # ======================================================

    @staticmethod
    def get_sale(sale_id):

        return Database.fetch_one(
            """
            SELECT *

            FROM sales

            WHERE id=?
            """,
            (sale_id,)
        )

    # ======================================================
    # Sale Items
    # ======================================================

    @staticmethod
    def get_sale_items(sale_id):

        return Database.fetch_all(
            """
            SELECT *

            FROM sales_items

            WHERE sale_id=?
            """,
            (sale_id,)
        )

    # ======================================================
    # Today Sales
    # ======================================================

    @staticmethod
    def today_sales():

        row = Database.fetch_one(
            """
            SELECT
                SUM(total_price) AS total

            FROM sales

            WHERE DATE(date)=DATE('now')
            """
        )

        if row["total"] is None:
            return 0

        return row["total"]

    # ======================================================
    # Total Sales
    # ======================================================

    @staticmethod
    def total_sales():

        row = Database.fetch_one(
            """
            SELECT
                SUM(total_price) AS total

            FROM sales
            """
        )

        if row["total"] is None:
            return 0

        return row["total"]

    # ======================================================
    # Sales Count
    # ======================================================

    @staticmethod
    def sales_count():

        row = Database.fetch_one(
            """
            SELECT
                COUNT(*) AS total

            FROM sales
            """
        )

        return row["total"]

    # ======================================================
    # Top Products
    # ======================================================

    @staticmethod
    def top_products(limit=10):

        return Database.fetch_all(
            """
            SELECT

                product_name,

                SUM(quantity) AS qty

            FROM sales_items

            GROUP BY product_name

            ORDER BY qty DESC

            LIMIT ?
            """,
            (limit,)
        )