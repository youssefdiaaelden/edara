from database.connection import get_connection


class RefundService:

    @staticmethod
    def get_sale_items(sale_id):

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
        SELECT
            id,
            product_name,
            quantity,
            total_price
        FROM sales_items
        WHERE sale_id=?
        """, (sale_id,))

        items = cursor.fetchall()

        conn.close()

        return items

    @staticmethod
    def refund_item(
        sale_id,
        item_id,
        product_name,
        old_qty,
        refund_qty,
        price_per_item
    ):

        conn = get_connection()
        cursor = conn.cursor()

        # رجع للمخزن
        cursor.execute("""
        UPDATE products
        SET quantity = quantity + ?
        WHERE name=?
        """, (
            refund_qty,
            product_name
        ))

        new_qty = old_qty - refund_qty
        new_total = new_qty * price_per_item

        if new_qty <= 0:

            cursor.execute("""
            DELETE FROM sales_items
            WHERE id=?
            """, (item_id,))

        else:

            cursor.execute("""
            UPDATE sales_items
            SET
                quantity=?,
                total_price=?
            WHERE id=?
            """, (
                new_qty,
                new_total,
                item_id
            ))

        cursor.execute("""
        SELECT SUM(total_price)
        FROM sales_items
        WHERE sale_id=?
        """, (sale_id,))

        total = cursor.fetchone()[0]

        if total is None:

            cursor.execute("""
            DELETE FROM sales
            WHERE id=?
            """, (sale_id,))

        else:

            cursor.execute("""
            UPDATE sales
            SET total_price=?
            WHERE id=?
            """, (
                total,
                sale_id
            ))

        conn.commit()
        conn.close()