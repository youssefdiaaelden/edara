from datetime import datetime

from database.db_manager import Database


class CustomerService:

    # =========================
    # Add Customer
    # =========================
    @staticmethod
    def add_customer(full_name, phone, address="", notes=""):

        return Database.execute(
            """
            INSERT INTO customers
            (
                full_name,
                phone,
                address,
                notes,
                created_at,
                updated_at
            )
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                full_name,
                phone,
                address,
                notes,
                datetime.now(),
                datetime.now()
            )
        )

    # =========================
    # Update Customer
    # =========================
    @staticmethod
    def update_customer(
            customer_id,
            full_name,
            phone,
            address,
            notes
    ):

        Database.execute(
            """
            UPDATE customers
            SET
                full_name=?,
                phone=?,
                address=?,
                notes=?,
                updated_at=?
            WHERE id=?
            """,
            (
                full_name,
                phone,
                address,
                notes,
                datetime.now(),
                customer_id
            )
        )

    # =========================
    # Delete Customer
    # =========================
    @staticmethod
    def delete_customer(customer_id):

        Database.execute(
            """
            DELETE FROM customers
            WHERE id=?
            """,
            (customer_id,)
        )

    # =========================
    # Get One Customer
    # =========================
    @staticmethod
    def get_customer(customer_id):

        return Database.fetch_one(
            """
            SELECT *
            FROM customers
            WHERE id=?
            """,
            (customer_id,)
        )

    # =========================
    # Get All Customers
    # =========================
    @staticmethod
    def get_all_customers():

        return Database.fetch_all(
            """
            SELECT *
            FROM customers
            ORDER BY id DESC
            """
        )

    @staticmethod
    def get_statement(customer_id):
        return Database.fetch_all(
            """
            SELECT *

            FROM customer_transactions

            WHERE customer_id=?

            ORDER BY id DESC
            """,
            (customer_id,)
        )
    # =========================
    # Search
    # =========================
    @staticmethod
    def search(search):

        return Database.fetch_all(
            """
            SELECT *
            FROM customers
            WHERE
                full_name LIKE ?
                OR phone LIKE ?
            ORDER BY id DESC
            """,
            (
                f"%{search}%",
                f"%{search}%"
            )
        )

    # =========================
    # Increase Credit
    # =========================
    @staticmethod
    def add_credit(customer_id, amount):
        Database.execute(
            """
            UPDATE customers

            SET credit = credit + ?

            WHERE id=?
            """,
            (
                amount,
                customer_id
            )
        )

        CustomerService.add_transaction(
            customer_id,
            "SALE",
            amount,
            "Credit Sale"
        )


    @staticmethod
    def add_transaction(
            customer_id,
            transaction_type,
            amount,
            description="",
            reference_id=None
    ):
        Database.execute(
            """
            INSERT INTO customer_transactions
            (
                customer_id,
                transaction_type,
                amount,
                reference_id,
                description
            )
            VALUES
            (
                ?,?,?,?,?
            )
            """,
            (
                customer_id,
                transaction_type,
                amount,
                reference_id,
                description
            )
        )

    # =========================
    # Receive Payment
    # =========================
    @staticmethod
    def pay_credit(customer_id, amount):
        Database.execute(
            """
            UPDATE customers

            SET credit = credit - ?

            WHERE id=?
            """,
            (
                amount,
                customer_id
            )
        )

        CustomerService.add_transaction(
            customer_id,
            "PAYMENT",
            -amount,
            "Customer Payment"
        )