class ReportService:

    @staticmethod
    def get_summary():
        ...

    @staticmethod
    def get_top_products():
        ...

    @staticmethod
    def get_daily_sales():
        ...

    @staticmethod
    def get_monthly_sales():
        ...

    @staticmethod
    def get_low_stock():
        ...

    @staticmethod
    def get_inventory_value():
        ...