from database.connection import get_connection


class InventoryService:

    @staticmethod
    def get_all_products(search=""):

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                id,
                name,
                sell_price,
                quantity
            FROM products
            WHERE name LIKE ?
               OR barcode LIKE ?
            ORDER BY id DESC
        """, (
            f"%{search}%",
            f"%{search}%"
        ))

        products = cursor.fetchall()

        conn.close()

        return products

    @staticmethod
    def get_product(barcode):

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                name,
                sell_price,
                quantity
            FROM products
            WHERE barcode=?
        """, (barcode,))

        product = cursor.fetchone()

        conn.close()

        return product

    @staticmethod
    def increase_stock(product_id, qty):

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE products
            SET quantity = quantity + ?
            WHERE id=?
        """, (
            qty,
            product_id
        ))

        conn.commit()
        conn.close()