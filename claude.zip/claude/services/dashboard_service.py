from database.connection import get_connection


class DashboardService:

    @staticmethod
    def get_dashboard_data():

        conn = get_connection()
        cursor = conn.cursor()

        # إجمالي المبيعات
        cursor.execute("""
        SELECT COALESCE(SUM(total_price), 0)
        FROM sales
        """)
        total_sales = cursor.fetchone()[0]

        # إجمالي قيمة المنتجات المباعة
        cursor.execute("""
        SELECT COALESCE(SUM(total_price), 0)
        FROM sales_items
        """)
        total_revenue = cursor.fetchone()[0]

        profit = total_sales - (total_revenue * 0.7)

        conn.close()

        return {
            "total_sales": total_sales,
            "profit": round(profit, 2)
        }