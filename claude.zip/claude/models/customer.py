from dataclasses import dataclass


@dataclass
class Customer:
    id: int = None

    full_name: str = ""

    phone: str = ""

    address: str = ""

    notes: str = ""

    credit: float = 0

    is_active: int = 1

    created_at: str = ""

    updated_at: str = ""
