def ar(text):
    reshaped = arabic_reshaper.reshape(str(text))
    return get_display(reshaped)
def ar_safe(text):
    # لو عربي → يعالجه، لو إنجليزي → يسيبه
    if any('\u0600' <= c <= '\u06FF' for c in text):
        return ar(text)
    return text