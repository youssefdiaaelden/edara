from flask import Flask, render_template
import sqlite3

app = Flask(__name__)

DB="../store.db"


def query(sql):

    conn=sqlite3.connect(DB)
    cursor=conn.cursor()

    cursor.execute(sql)

    result=cursor.fetchone()[0]

    conn.close()

    return result or 0


@app.route("/")
def dashboard():

    total_sales=query("""
    SELECT SUM(total_price)
    FROM sales
    """)

    invoices=query("""
    SELECT COUNT(*)
    FROM sales
    """)

    products=query("""
    SELECT COUNT(*)
    FROM products
    """)

    stock=query("""
    SELECT SUM(quantity)
    FROM products
    """)

    low_stock=query("""
    SELECT COUNT(*)
    FROM products
    WHERE quantity<=5
    """)

    return render_template(
        "dashboard.html",

        total_sales=total_sales,
        invoices=invoices,
        products=products,
        stock=stock,
        low_stock=low_stock
    )


app.run(debug=True)