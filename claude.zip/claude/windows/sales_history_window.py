from services.sales_service import SalesService


class SalesHistoryDialog(QDialog):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Sales History")
        self.resize(900, 500)

        layout = QVBoxLayout()

        self.table = QTableWidget()

        self.table.setColumnCount(5)

        self.table.setHorizontalHeaderLabels([
            "ID",
            "Date",
            "Total",
            "Cashier",
            "Refund"
        ])

        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch
        )

        layout.addWidget(self.table)

        self.setLayout(layout)

        self.load_sales()

    def load_sales(self):
        sales = SalesService.get_sales_history()

        self.table.setRowCount(0)

        for row_idx, sale in enumerate(sales):
            self.table.insertRow(row_idx)

            self.table.setItem(
                row_idx,
                0,
                QTableWidgetItem(str(sale["id"]))
            )

            self.table.setItem(
                row_idx,
                1,
                QTableWidgetItem(str(sale["date"]))
            )

            self.table.setItem(
                row_idx,
                2,
                QTableWidgetItem(str(sale["total_price"]))
            )

            self.table.setItem(
                row_idx,
                3,
                QTableWidgetItem(str(sale["cashier_name"]))
            )

            refund_btn = QPushButton("Refund")

            refund_btn.setStyleSheet("""
            background-color:red;
            color:white;
            """)

            refund_btn.clicked.connect(
                partial(
                    self.open_refund_dialog,
                    sale["id"]
                )
            )

            self.table.setCellWidget(
                row_idx,
                4,
                refund_btn
            )
    def open_refund_dialog(self, sale_id):

        dialog = RefundDialog(sale_id)

        dialog.exec()

        self.load_sales()
