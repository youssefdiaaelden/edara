from services.refund_service import RefundService


class RefundDialog(QDialog):
    def __init__(self, sale_id):
        super().__init__()

        self.sale_id = sale_id

        self.setWindowTitle("Refund Items")
        self.resize(700, 400)

        layout = QVBoxLayout()

        self.table = QTableWidget()

        self.table.setColumnCount(5)

        self.table.setHorizontalHeaderLabels([
            "Product",
            "Bought Qty",
            "Refund Qty",
            "Price",
            "Refund"
        ])

        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch
        )

        layout.addWidget(self.table)

        self.setLayout(layout)

        self.load_items()

    def load_items(self):
        items = RefundService.get_sale_items(self.sale_id)
        self.table.setRowCount(0)

        for row_idx, item in enumerate(items):
            item_id = item["id"]
            product_name = item["product_name"]
            qty = item["quantity"]
            total_price = item["total_price"]
            self.table.insertRow(row_idx)

            price_per_item = total_price / qty

            self.table.setItem(
                row_idx,
                0,
                QTableWidgetItem(product_name)
            )

            self.table.setItem(
                row_idx,
                1,
                QTableWidgetItem(str(qty))
            )

            spin = QSpinBox()
            spin.setMinimum(1)
            spin.setMaximum(qty)

            self.table.setCellWidget(
                row_idx,
                2,
                spin
            )

            self.table.setItem(
                row_idx,
                3,
                QTableWidgetItem(str(price_per_item))
            )

            refund_btn = QPushButton("Refund")

            refund_btn.setStyleSheet("""
            background-color:red;
            color:white;
            """)

            refund_btn.clicked.connect(
                partial(
                    self.refund_item,
                    item_id,
                    product_name,
                    qty,
                    price_per_item,
                    spin
                )
            )

            self.table.setCellWidget(
                row_idx,
                4,
                refund_btn
            )

    def refund_item(
            self,
            item_id,
            product_name,
            old_qty,
            price_per_item,
            spin
    ):
        RefundService.refund_item(
            self.sale_id,
            item_id,
            product_name,
            old_qty,
            spin.value(),
            price_per_item
        )

        self.load_items()

        print("✅ Partial Refund Done")
