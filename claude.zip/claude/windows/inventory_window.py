from services.inventory_service import InventoryService
class InventoryDialog(QDialog):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Inventory")
        self.resize(850, 500)

        layout = QVBoxLayout()

        self.search = QLineEdit()
        self.search.setPlaceholderText("Search name or barcode...")
        self.search.textChanged.connect(self.load_products)

        layout.addWidget(self.search)

        self.table = QTableWidget()

        self.table.setColumnCount(6)

        self.table.setHorizontalHeaderLabels([
            "ID",
            "Name",
            "Price",
            "Qty",
            "+Qty",
            "Edit"
        ])

        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        layout.addWidget(self.table)

        self.setLayout(layout)

        self.load_products()

    def load_products(self):

        conn = sqlite3.connect("store.db")
        cursor = conn.cursor()

        search = self.search.text()

        cursor.execute("""
        SELECT id, name, sell_price, quantity
        FROM products
        WHERE name LIKE ? OR barcode LIKE ?
        ORDER BY id DESC
        """, (
            f"%{search}%",
            f"%{search}%"
        ))

        products = InventoryService.get_all_products(
            self.search.text()
        )
        self.table.setRowCount(0)

        for row_idx, product in enumerate(products):

            self.table.insertRow(row_idx)

            for col_idx, value in enumerate(product):

                item = QTableWidgetItem(str(value))

                if col_idx == 3:

                    qty = int(value)

                    if qty <= 5:
                        item.setBackground(Qt.red)

                    elif qty <= 10:
                        item.setBackground(Qt.yellow)

                self.table.setItem(row_idx, col_idx, item)

            qty_btn = QPushButton("+10 Qty")
            qty_btn.clicked.connect(partial(self.add_qty, product))

            self.table.setCellWidget(row_idx, 4, qty_btn)

            edit_btn = QPushButton("Edit")
            edit_btn.clicked.connect(partial(self.open_edit_dialog, product))

            self.table.setCellWidget(row_idx, 5, edit_btn)

        conn.close()

    def add_qty(self, product):

        product_id, name, price, qty = product

        cursor = conn.cursor()

        cursor.execute("""
        UPDATE products
        SET quantity=?
        WHERE id=?
        """, (
            qty + 10,
            product_id
        ))

        conn.commit()
        conn.close()

        self.load_products()

    def open_edit_dialog(self, product):

        dialog = EditProductDialog(product)

        if dialog.exec():
            self.load_products()
