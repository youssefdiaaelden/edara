class ReportsDialog(QDialog):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Reports")

        layout = QVBoxLayout()

        self.label = QLabel()

        layout.addWidget(self.label)

        self.setLayout(layout)

        self.load_reports()

    def load_reports(self):

        conn = sqlite3.connect("store.db")
        cursor = conn.cursor()

        cursor.execute("SELECT SUM(total_price) FROM sales")

        total_sales = cursor.fetchone()[0] or 0

        cursor.execute("""
        SELECT product_name, SUM(quantity)
        FROM sales_items
        GROUP BY product_name
        ORDER BY SUM(quantity) DESC
        LIMIT 3
        """)

        top_products = cursor.fetchall()

        text = f"💰 Total Sales: {total_sales}\n\n"

        text += "🏆 Top Products:\n"

        for p in top_products:
            text += f"{p[0]} ({p[1]})\n"

        self.label.setText(text)

        conn.close()
