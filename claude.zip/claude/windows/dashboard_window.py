from services.dashboard_service import DashboardService
class DashboardDialog(QDialog):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("dashboard")

        layout = QVBoxLayout()

        self.label = QLabel()

        layout.addWidget(self.label)

        self.setLayout(layout)

        self.load_data()

    def load_data(self):

        data = DashboardService.get_dashboard_data()

        top_pred = predict_top_products()
        profit_pred = predict_profit()

        if hasattr(top_pred, "iterrows") and len(top_pred) > 0:

            top_text = "\n".join([
                f"{row['product_name']} ({row['quantity']})"
                for _, row in top_pred.iterrows()
            ])

        else:
            top_text = "No data"

        self.label.setText(f"""
    💰 Total Sales: {data["total_sales"]} EGP

    📈 Profit: {data["profit"]} EGP

    🤖 Predicted Top Products:
    {top_text}

    🤖 Expected Profit:
    {profit_pred}
    """)