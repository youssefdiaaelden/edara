class AddProductDialog(QDialog):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Add Product")

        layout = QFormLayout()

        self.name = QLineEdit()
        self.barcode = QLineEdit()
        self.cost = QLineEdit()
        self.profit = QLineEdit()
        self.qty = QLineEdit()

        layout.addRow("Name:", self.name)
        layout.addRow("Barcode:", self.barcode)
        layout.addRow("Cost:", self.cost)
        layout.addRow("Profit:", self.profit)
        layout.addRow("Quantity:", self.qty)

        self.barcode.setFocus()
        self.barcode.returnPressed.connect(self.fill_product_data)

        btn = QPushButton("Save")
        btn.clicked.connect(self.save_product)

        layout.addWidget(btn)
        self.setLayout(layout)

    def fill_product_data(self):

        barcode = self.barcode.text()

        conn = sqlite3.connect("store.db")
        cursor = conn.cursor()

        cursor.execute("""
        SELECT name, cost_price, profit_margin, quantity
        FROM products
        WHERE barcode=?
        """, (barcode,))

        product = cursor.fetchone()

        conn.close()

        if product:

            name, cost, profit, qty = product

            self.name.setText(name)
            self.cost.setText(str(cost))
            self.profit.setText(str(profit))
            self.qty.setText("1")

        else:
            self.name.setFocus()

    def save_product(self):

        try:
            try:
                cost = float(self.cost.text())
            except:
                return
            profit = float(self.profit.text())
            qty = int(self.qty.text())

        except:
            print("❌ Invalid Input")
            return

        barcode = self.barcode.text()

        conn = sqlite3.connect("store.db")
        cursor = conn.cursor()

        cursor.execute("""
        SELECT id, quantity
        FROM products
        WHERE barcode=?
        """, (barcode,))

        existing = cursor.fetchone()

        sell_price = cost + profit

        if existing:

            product_id, old_qty = existing

            cursor.execute("""
            UPDATE products
            SET
                name=?,
                cost_price=?,
                sell_price=?,
                profit_margin=?,
                quantity=?
            WHERE id=?
            """, (
                self.name.text(),
                cost,
                sell_price,
                profit,
                old_qty + qty,
                product_id
            ))

        else:

            cursor.execute("""
            INSERT INTO products
            (name, barcode, cost_price, sell_price, profit_margin, quantity)
            VALUES (?, ?, ?, ?, ?, ?)
            """, (
                self.name.text(),
                barcode,
                cost,
                sell_price,
                profit,
                qty
            ))

        conn.commit()
        conn.close()

        self.accept()
class EditProductDialog(QDialog):
    def __init__(self, product):
        super().__init__()

        self.product = product

        self.setWindowTitle("Edit Product")
        self.resize(350, 250)

        layout = QFormLayout()

        self.name = QLineEdit()
        self.barcode = QLineEdit()
        self.cost = QLineEdit()
        self.profit = QLineEdit()
        self.qty = QLineEdit()

        layout.addRow("Name:", self.name)
        layout.addRow("Barcode:", self.barcode)
        layout.addRow("Cost:", self.cost)
        layout.addRow("Profit:", self.profit)
        layout.addRow("Quantity:", self.qty)

        product_id, name, sell_price, quantity = product

        conn = sqlite3.connect("store.db")
        cursor = conn.cursor()

        cursor.execute("""
        SELECT barcode, cost_price, profit_margin
        FROM products
        WHERE id=?
        """, (product_id,))

        extra = cursor.fetchone()

        conn.close()

        barcode, cost, profit = extra

        self.name.setText(name)
        self.barcode.setText(barcode)
        self.cost.setText(str(cost))
        self.profit.setText(str(profit))
        self.qty.setText(str(quantity))

        save_btn = QPushButton("Save Changes")
        save_btn.clicked.connect(self.save_changes)

        delete_btn = QPushButton("Delete Product")
        delete_btn.setStyleSheet("background-color:red;")
        delete_btn.clicked.connect(self.delete_product)

        layout.addWidget(save_btn)
        layout.addWidget(delete_btn)

        self.setLayout(layout)

    def save_changes(self):

        product_id = self.product[0]

        try:
            try:
                cost = float(self.cost.text())
            except:
                return
            profit = float(self.profit.text())
            qty = int(self.qty.text())

        except:
            print("❌ Invalid Input")
            return

        conn = sqlite3.connect("store.db")
        cursor = conn.cursor()

        cursor.execute("""
        SELECT id
        FROM products
        WHERE barcode=? AND id!=?
        """, (
            self.barcode.text(),
            product_id
        ))

        exists = cursor.fetchone()

        if exists:
            print("❌ Barcode already exists")
            conn.close()
            return

        sell_price = cost + profit

        cursor.execute("""
        UPDATE products
        SET
            name=?,
            barcode=?,
            cost_price=?,
            profit_margin=?,
            sell_price=?,
            quantity=?
        WHERE id=?
        """, (
            self.name.text(),
            self.barcode.text(),
            cost,
            profit,
            sell_price,
            qty,
            product_id
        ))

        conn.commit()
        conn.close()

        self.accept()

    def delete_product(self):

        product_id = self.product[0]

        conn = sqlite3.connect("store.db")
        cursor = conn.cursor()

        cursor.execute("""
        DELETE FROM products
        WHERE id=?
        """, (product_id,))

        conn.commit()
        conn.close()

        self.accept()
