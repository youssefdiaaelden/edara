from PySide6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QLabel,
    QDoubleSpinBox,
    QTextEdit,
    QPushButton,
    QMessageBox
)

from services.customer_service import CustomerService


class PaymentWindow(QDialog):

    def __init__(self, customer):

        super().__init__()

        self.customer = customer

        self.setWindowTitle("Receive Payment")

        self.resize(400, 300)

        self.build_ui()

    # =====================================================

    def build_ui(self):

        layout = QVBoxLayout()

        self.customer_label = QLabel(
            f"Customer : {self.customer['full_name']}"
        )

        layout.addWidget(self.customer_label)

        self.credit_label = QLabel(
            f"Current Credit : {self.customer['credit']} EGP"
        )

        layout.addWidget(self.credit_label)

        layout.addWidget(QLabel("Amount"))

        self.amount = QDoubleSpinBox()

        self.amount.setMaximum(999999999)

        self.amount.setDecimals(2)

        layout.addWidget(self.amount)

        layout.addWidget(QLabel("Notes"))

        self.notes = QTextEdit()

        self.notes.setFixedHeight(80)

        layout.addWidget(self.notes)

        self.save_btn = QPushButton("Receive Payment")

        layout.addWidget(self.save_btn)

        self.setLayout(layout)

        self.save_btn.clicked.connect(
            self.save_payment
        )

    # =====================================================

    def save_payment(self):

        amount = self.amount.value()

        if amount <= 0:

            QMessageBox.warning(

                self,

                "Error",

                "Amount must be greater than zero."

            )

            return

        CustomerService.receive_payment(

            self.customer["id"],

            amount,

            self.notes.toPlainText()

        )

        QMessageBox.information(

            self,

            "Done",

            "Payment Saved Successfully."

        )

        self.accept()