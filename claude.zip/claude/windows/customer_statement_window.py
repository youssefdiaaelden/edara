from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView
)

from services.customer_service import CustomerService


class CustomerStatementWindow(QWidget):

    def __init__(self, customer_id):

        super().__init__()

        self.customer_id = customer_id

        self.setWindowTitle("Customer Statement")

        self.resize(1000, 650)

        self.build_ui()

        self.load_data()

    # ======================================================
    # UI
    # ======================================================

    def build_ui(self):

        layout = QVBoxLayout()

        # ---------------- Customer Info ----------------

        self.name_label = QLabel()

        self.phone_label = QLabel()

        self.address_label = QLabel()

        self.credit_label = QLabel()

        layout.addWidget(self.name_label)
        layout.addWidget(self.phone_label)
        layout.addWidget(self.address_label)
        layout.addWidget(self.credit_label)

        # ---------------- Table ----------------

        self.table = QTableWidget()

        self.table.setColumnCount(5)

        self.table.setHorizontalHeaderLabels([
            "Date",
            "Type",
            "Amount",
            "Description",
            "Reference"
        ])

        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch
        )

        layout.addWidget(self.table)

        # ---------------- Buttons ----------------

        buttons = QHBoxLayout()

        self.refresh_btn = QPushButton("Refresh")

        self.print_btn = QPushButton("Print PDF")

        buttons.addWidget(self.refresh_btn)

        buttons.addWidget(self.print_btn)

        layout.addLayout(buttons)

        self.setLayout(layout)

        self.refresh_btn.clicked.connect(
            self.load_data
        )

        self.print_btn.clicked.connect(
            self.print_statement
        )

    # ======================================================
    # Load
    # ======================================================

    def load_data(self):

        customer = CustomerService.get_customer(
            self.customer_id
        )

        if customer is None:
            return

        self.name_label.setText(
            f"Name : {customer['full_name']}"
        )

        self.phone_label.setText(
            f"Phone : {customer['phone']}"
        )

        self.address_label.setText(
            f"Address : {customer['address']}"
        )

        self.credit_label.setText(
            f"Current Credit : {customer['credit']} EGP"
        )

        transactions = CustomerService.get_statement(
            self.customer_id
        )

        self.table.setRowCount(0)

        for row, transaction in enumerate(transactions):

            self.table.insertRow(row)

            self.table.setItem(
                row,
                0,
                QTableWidgetItem(
                    str(transaction["created_at"])
                )
            )

            self.table.setItem(
                row,
                1,
                QTableWidgetItem(
                    transaction["transaction_type"]
                )
            )

            self.table.setItem(
                row,
                2,
                QTableWidgetItem(
                    str(transaction["amount"])
                )
            )

            self.table.setItem(
                row,
                3,
                QTableWidgetItem(
                    transaction["description"] or ""
                )
            )

            self.table.setItem(
                row,
                4,
                QTableWidgetItem(
                    str(transaction["reference_id"] or "")
                )
            )

    # ======================================================
    # Print
    # ======================================================

    def print_statement(self):

        print("PDF Statement Coming Soon...")