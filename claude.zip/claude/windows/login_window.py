from PySide6.QtWidgets import *

from services.auth_service import login


class LoginWindow(QDialog):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Login")

        layout = QFormLayout()

        self.username = QLineEdit()

        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)

        layout.addRow("Username:", self.username)
        layout.addRow("Password:", self.password)

        btn = QPushButton("Login")
        btn.clicked.connect(self.handle_login)

        layout.addWidget(btn)

        self.setLayout(layout)

        self.role = None
        self.username_value = None

    def handle_login(self):

        from auth import login

        role = login(
            self.username.text(),
            self.password.text()
        )

        if role:
            self.username_value = self.username.text()
            self.role = role
            self.accept()

        else:

            self.username.clear()
            self.password.clear()

            print("❌ Wrong Login")
