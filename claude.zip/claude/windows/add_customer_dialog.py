from PySide6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QTextEdit,
    QPushButton,
    QMessageBox
)

from services.customer_service import CustomerService


class AddCustomerDialog(QDialog):

    def __init__(self, customer=None):
        super().__init__()

        self.customer = customer

        self.setWindowTitle("Customer")

        self.resize(450, 450)

        self.build_ui()

        if customer:
            self.load_customer()

    # ======================================================
    # UI
    # ======================================================

    def build_ui(self):

        layout = QVBoxLayout()

        # Name

        layout.addWidget(QLabel("Full Name"))

        self.name_edit = QLineEdit()

        layout.addWidget(self.name_edit)

        # Phone

        layout.addWidget(QLabel("Phone"))

        self.phone_edit = QLineEdit()

        layout.addWidget(self.phone_edit)

        # Address

        layout.addWidget(QLabel("Address"))

        self.address_edit = QTextEdit()

        self.address_edit.setFixedHeight(70)

        layout.addWidget(self.address_edit)

        # Notes

        layout.addWidget(QLabel("Notes"))

        self.notes_edit = QTextEdit()

        self.notes_edit.setFixedHeight(90)

        layout.addWidget(self.notes_edit)

        # Buttons

        buttons = QHBoxLayout()

        self.save_btn = QPushButton("Save")

        self.cancel_btn = QPushButton("Cancel")

        buttons.addWidget(self.save_btn)

        buttons.addWidget(self.cancel_btn)

        layout.addLayout(buttons)

        self.setLayout(layout)

        self.save_btn.clicked.connect(self.save_customer)

        self.cancel_btn.clicked.connect(self.reject)

    # ======================================================
    # Load Customer
    # ======================================================

    def load_customer(self):

        self.name_edit.setText(
            self.customer["full_name"]
        )

        self.phone_edit.setText(
            self.customer["phone"] or ""
        )

        self.address_edit.setPlainText(
            self.customer["address"] or ""
        )

        self.notes_edit.setPlainText(
            self.customer["notes"] or ""
        )

    # ======================================================
    # Save
    # ======================================================

    def save_customer(self):

        name = self.name_edit.text().strip()

        phone = self.phone_edit.text().strip()

        address = self.address_edit.toPlainText().strip()

        notes = self.notes_edit.toPlainText().strip()

        if not name:

            QMessageBox.warning(

                self,

                "Error",

                "Customer name is required."

            )

            return

        try:

            if self.customer is None:

                CustomerService.add_customer(

                    full_name=name,

                    phone=phone,

                    address=address,

                    notes=notes

                )

            else:

                CustomerService.update_customer(

                    self.customer["id"],

                    name,

                    phone,

                    address,

                    notes

                )

            self.accept()

        except Exception as e:

            QMessageBox.critical(

                self,

                "Database Error",

                str(e)

            )