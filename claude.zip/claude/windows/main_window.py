class CashierApp(QWidget):
    def __init__(self, role, username):
        super().__init__()

        self.role = role
        self.username = username

        self.setWindowTitle("Store System Pro")
        self.resize(1000, 600)

        self.cart = []

        self.setStyleSheet("""
        QWidget {
            background-color: #1e1e2f;
            color: white;
        }
        """)

        main_layout = QHBoxLayout()

        left_layout = QVBoxLayout()
        right_layout = QVBoxLayout()

        # ================== BARCODE ==================
        self.barcode_input = QLineEdit()

        self.barcode_input.setPlaceholderText("Scan Barcode...")

        self.barcode_input.returnPressed.connect(self.add_product)

        left_layout.addWidget(self.barcode_input)

        # ================== TABLE ==================
        self.table = QTableWidget(0, 5)

        self.table.setHorizontalHeaderLabels([
            "Product",
            "Qty",
            "Price",
            "Total",
            "Delete"
        ])

        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        left_layout.addWidget(self.table)

        # ================== TOTAL ==================
        self.total_label = QLabel("0 EGP")

        self.total_label.setStyleSheet("""
        font-size: 24px;
        color: #00ffcc;
        """)

        left_layout.addWidget(self.total_label)

        # ================== BUTTONS ==================
        self.add_btn = QPushButton("Add Product")
        self.inventory_btn = QPushButton("Inventory")
        self.dashboard_btn = QPushButton("dashboard")
        self.reports_btn = QPushButton("Reports")
        self.complete_btn = QPushButton("Complete Sale")
        self.history_btn = QPushButton("Sales History")

        if self.role == "cashier":

            self.add_btn.hide()
            self.inventory_btn.hide()
            self.dashboard_btn.hide()
            self.reports_btn.hide()

        elif self.role == "inventory":

            self.dashboard_btn.hide()
            self.reports_btn.hide()

        elif self.role == "accountant":

            self.add_btn.hide()
            self.inventory_btn.hide()

        for btn, func in [

            (self.add_btn, self.open_add_product),
            (self.inventory_btn, self.open_inventory),
            (self.dashboard_btn, self.open_dashboard),
            (self.reports_btn, self.open_reports),
            (self.complete_btn, self.handle_complete_sale),
            (self.history_btn, self.open_history),
        ]:

            btn.clicked.connect(func)

            right_layout.addWidget(btn)

        main_layout.addLayout(left_layout, 3)
        main_layout.addLayout(right_layout, 1)

        self.setLayout(main_layout)

    # ================== OPEN WINDOWS ==================
    def open_add_product(self):
        AddProductDialog().exec()

    def open_inventory(self):
        InventoryDialog().exec()

    def open_dashboard(self):
        DashboardDialog().exec()

    def open_reports(self):
        ReportsDialog().exec()

    def open_history(self):
        SalesHistoryDialog().exec()

    # ================== ADD PRODUCT ==================
    def add_product(self):

        barcode = self.barcode_input.text()

        product = get_product_by_barcode(barcode)

        if not product:

            winsound.Beep(300, 700)

            self.barcode_input.clear()

            return

        name, price, stock = product

        if stock <= 0:

            winsound.Beep(300, 700)

            print("❌ Out Of Stock")

            return

        for item in self.cart:

            if item["barcode"] == barcode:

                item["qty"] += 1

                self.update_table()

                winsound.Beep(1000, 200)

                self.barcode_input.clear()

                return

        self.cart.append({
            "barcode": barcode,
            "name": name,
            "price": price,
            "qty": 1
        })

        winsound.Beep(1000, 200)

        self.update_table()

        self.barcode_input.clear()

    # ================== UPDATE TABLE ==================
    def update_table(self):

        self.table.setRowCount(0)

        total = 0

        for row_idx, item in enumerate(self.cart):

            self.table.insertRow(row_idx)

            item_total = item["qty"] * item["price"]

            total += item_total

            self.table.setItem(
                row_idx,
                0,
                QTableWidgetItem(item["name"])
            )

            self.table.setItem(
                row_idx,
                1,
                QTableWidgetItem(str(item["qty"]))
            )

            self.table.setItem(
                row_idx,
                2,
                QTableWidgetItem(str(item["price"]))
            )

            self.table.setItem(
                row_idx,
                3,
                QTableWidgetItem(str(item_total))
            )

            btn = QPushButton("✖")

            btn.clicked.connect(
                lambda checked, i=row_idx: self.remove_item(i)
            )

            self.table.setCellWidget(row_idx, 4, btn)

        self.total_label.setText(f"{total} EGP")

    # ================== REMOVE ITEM ==================
    def remove_item(self, index):

        if index < len(self.cart):

            del self.cart[index]

            self.update_table()

            winsound.Beep(400, 100)

    # ================== COMPLETE SALE ==================
    def handle_complete_sale(self):

        if not self.cart:
            return

        total = complete_sale(
            self.cart,
            self.username
        )

        print_receipt(
            self.cart,
            total,
            self.username
        )


        self.cart = []

        self.update_table()

        winsound.Beep(1500, 300)
