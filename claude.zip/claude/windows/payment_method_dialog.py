from PySide6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QLabel,
    QPushButton,
    QRadioButton,
    QComboBox,
    QTextEdit,
    QMessageBox
)

from services.customer_service import CustomerService


class PaymentMethodDialog(QDialog):

    def __init__(self):

        super().__init__()

        self.payment_type = "CASH"

        self.customer_id = None

        self.notes = ""

        self.setWindowTitle("Complete Sale")

        self.resize(450, 350)

        self.build_ui()

    # ======================================================

    def build_ui(self):

        layout = QVBoxLayout()

        layout.addWidget(QLabel("Payment Method"))

        self.cash_radio = QRadioButton("Cash")

        self.credit_radio = QRadioButton("Credit")

        self.cash_radio.setChecked(True)

        layout.addWidget(self.cash_radio)

        layout.addWidget(self.credit_radio)

        layout.addWidget(QLabel("Customer"))

        self.customer_combo = QComboBox()

        self.customer_combo.setEnabled(False)

        layout.addWidget(self.customer_combo)

        layout.addWidget(QLabel("Notes"))

        self.notes_edit = QTextEdit()

        layout.addWidget(self.notes_edit)

        self.complete_btn = QPushButton("Complete Sale")

        layout.addWidget(self.complete_btn)

        self.setLayout(layout)

        self.credit_radio.toggled.connect(
            self.toggle_credit
        )

        self.complete_btn.clicked.connect(
            self.complete
        )

        self.load_customers()

    # ======================================================

    def load_customers(self):

        self.customer_combo.clear()

        customers = CustomerService.get_all_customers()

        for customer in customers:

            self.customer_combo.addItem(

                customer["full_name"],

                customer["id"]

            )

    # ======================================================

    def toggle_credit(self):

        enabled = self.credit_radio.isChecked()

        self.customer_combo.setEnabled(enabled)

    # ======================================================

    def complete(self):

        if self.cash_radio.isChecked():

            self.payment_type = "CASH"

        else:

            self.payment_type = "CREDIT"

            if self.customer_combo.count() == 0:

                QMessageBox.warning(

                    self,

                    "No Customers",

                    "Please add a customer first."

                )

                return

            self.customer_id = self.customer_combo.currentData()

        self.notes = self.notes_edit.toPlainText()

        self.accept()