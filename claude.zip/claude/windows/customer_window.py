from windows.payment_window import PaymentWindow
from windows.customer_statement_window import CustomerStatementWindow
from windows.add_customer_dialog import AddCustomerDialog
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QPushButton,
    QLineEdit,
    QLabel,
    QTableWidget,
    QTableWidgetItem,
    QMessageBox,
    QHeaderView
)

from services.customer_service import CustomerService


class CustomerWindow(QWidget):

    def __init__(self):

        super().__init__()

        self.setWindowTitle("Customers")

        self.resize(1100, 650)

        self.build_ui()

        self.load_customers()

    # ==========================================================
    # UI
    # ==========================================================

    def build_ui(self):

        main_layout = QVBoxLayout()

        title = QLabel("Customers")

        title.setStyleSheet("""
        font-size:24px;
        font-weight:bold;
        """)

        main_layout.addWidget(title)

        # =======================
        # Search
        # =======================

        top_layout = QHBoxLayout()

        self.search_edit = QLineEdit()

        self.search_edit.setPlaceholderText(
            "Search by name or phone..."
        )

        self.search_edit.textChanged.connect(
            self.search_customer
        )

        add_btn = QPushButton("Add Customer")

        add_btn.clicked.connect(
            self.add_customer
        )

        top_layout.addWidget(self.search_edit)

        top_layout.addWidget(add_btn)

        main_layout.addLayout(top_layout)

        # =======================
        # Table
        # =======================

        self.table = QTableWidget()

        self.table.setColumnCount(7)

        self.table.setHorizontalHeaderLabels([

            "ID",

            "Name",

            "Phone",

            "Credit",

            "Address",

            "Notes",

            "Status"

        ])

        self.table.horizontalHeader().setSectionResizeMode(

            QHeaderView.Stretch

        )

        self.table.setSelectionBehavior(

            QTableWidget.SelectRows

        )

        self.table.setEditTriggers(

            QTableWidget.NoEditTriggers

        )

        main_layout.addWidget(self.table)

        # =======================
        # Bottom Buttons
        # =======================

        bottom = QHBoxLayout()

        self.edit_btn = QPushButton("Edit")

        self.delete_btn = QPushButton("Delete")

        self.statement_btn = QPushButton("Statement")

        self.payment_btn = QPushButton("Receive Payment")

        bottom.addWidget(self.edit_btn)

        bottom.addWidget(self.delete_btn)

        bottom.addWidget(self.statement_btn)

        bottom.addWidget(self.payment_btn)

        main_layout.addLayout(bottom)

        self.setLayout(main_layout)

        # events

        self.edit_btn.clicked.connect(
            self.edit_customer
        )

        self.delete_btn.clicked.connect(
            self.delete_customer
        )

        self.statement_btn.clicked.connect(
            self.open_statement
        )

        self.payment_btn.clicked.connect(
            self.receive_payment
        )

    # ==========================================================
    # Load
    # ==========================================================

    def load_customers(self):

        customers = CustomerService.get_all_customers()

        self.fill_table(customers)

    # ==========================================================
    # Fill Table
    # ==========================================================

    def fill_table(self, customers):

        self.table.setRowCount(0)

        for row_index, customer in enumerate(customers):

            self.table.insertRow(row_index)

            self.table.setItem(
                row_index,
                0,
                QTableWidgetItem(str(customer["id"]))
            )

            self.table.setItem(
                row_index,
                1,
                QTableWidgetItem(customer["full_name"])
            )

            self.table.setItem(
                row_index,
                2,
                QTableWidgetItem(customer["phone"] or "")
            )

            self.table.setItem(
                row_index,
                3,
                QTableWidgetItem(str(customer["credit"]))
            )

            self.table.setItem(
                row_index,
                4,
                QTableWidgetItem(customer["address"] or "")
            )

            self.table.setItem(
                row_index,
                5,
                QTableWidgetItem(customer["notes"] or "")
            )

            status = "Active"

            if customer["is_active"] == 0:
                status = "Disabled"

            self.table.setItem(
                row_index,
                6,
                QTableWidgetItem(status)
            )

    # ==========================================================
    # Search
    # ==========================================================

    def search_customer(self):

        text = self.search_edit.text()

        if text == "":
            self.load_customers()

            return

        customers = CustomerService.search(text)

        self.fill_table(customers)

    # ==========================================================
    # Selected Customer
    # ==========================================================

    def selected_customer_id(self):

        row = self.table.currentRow()

        if row < 0:
            return None

        return int(

            self.table.item(row, 0).text()

        )

    # ==========================================================
    # Buttons
    # ==========================================================

    def add_customer(self):

        dialog = AddCustomerDialog()

        if dialog.exec():
            self.load_customers()

    def edit_customer(self):

        customer_id = self.selected_customer_id()

        if customer_id is None:
            return

        customer = CustomerService.get_customer(customer_id)

        dialog = AddCustomerDialog(customer)

        if dialog.exec():
            self.load_customers()

    def delete_customer(self):

        customer_id = self.selected_customer_id()

        if customer_id is None:
            return

        reply = QMessageBox.question(

            self,

            "Delete",

            "Delete selected customer?"

        )

        if reply == QMessageBox.Yes:
            CustomerService.delete_customer(

                customer_id

            )

            self.load_customers()

    def open_statement(self):

        customer_id = self.selected_customer_id()

        if customer_id is None:
            return

        self.statement_window = CustomerStatementWindow(
            customer_id
        )

        self.statement_window.show()

    def receive_payment(self):

        customer_id = self.selected_customer_id()

        if customer_id is None:
            return

        customer = CustomerService.get_customer(
            customer_id
        )

        dialog = PaymentWindow(customer)

        if dialog.exec():
            self.load_customers()