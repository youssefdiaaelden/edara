import pandas as pd

import joblib

import sqlite3

from config import DATABASE


# ================== TOP PRODUCTS PREDICTION ==================
def predict_top_products():
    df = load_data()

    df_grouped = df.groupby('product_name')['quantity'].sum().reset_index()

    top3 = df_grouped.sort_values(by='quantity', ascending=False).head(3)

    return top3


# ================== PROFIT PREDICTION ==================
def predict_profit():
    df = load_data()

    df['month'] = df['date'].dt.month
    monthly = df.groupby('month')['total_price'].sum().reset_index()

    if len(monthly) < 2:
        return "Not enough data"

    X = monthly[['month']]
    y = monthly['total_price']

    model = LinearRegression()
    model.fit(X, y)

    future_months = [[monthly['month'].max() + i] for i in range(1, 4)]
    prediction = model.predict(future_months)

    return sum(prediction)